import ProductCard from "./ProductCard";
import productViolao from "@/assets/product-violao.jpg";
import productBooks from "@/assets/product-books.jpg";
import productBackpack from "@/assets/product-backpack.jpg";
import productAnalogCamera from "@/assets/product-analog-camera.jpg";
import productSneakers from "@/assets/product-sneakers.jpg";
import productLamp from "@/assets/product-lamp.jpg";

const products = [
  { image: productViolao, name: "Violão Acústico Giannini", price: "R$300,00 em até 10x sem juros!" },
  { image: productBooks, name: "Kit de Livros de Aventura", price: "R$300,00 em até 10x sem juros!" },
  { image: productBackpack, name: "Mochila para Notebook", price: "R$300,00 em até 10x sem juros!" },
  { image: productAnalogCamera, name: "Câmera analógica", price: "R$300,00 em até 10x sem juros!" },
  { image: productSneakers, name: "Tênis Nike Airforce", price: "R$300,00 em até 10x sem juros!" },
  { image: productLamp, name: "Luminária Vintage", price: "R$300,00 em até 10x sem juros!" },
];

const RecentItemsSection = () => {
  return (
    <section className="container py-12">
      <h2 className="text-2xl font-bold mb-1">Itens adicionados recentemente</h2>
      <p className="text-xs text-muted-foreground mb-6">60 itens com um novo começo adicionados hoje!</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {products.map((product, i) => (
          <ProductCard key={i} {...product} />
        ))}
      </div>
      {/* Pagination */}
      <div className="mt-8 flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span>Mostrar</span>
          <select className="rounded-md border border-border bg-card px-2 py-1 text-xs">
            <option>6</option>
            <option>12</option>
            <option>24</option>
          </select>
          <span>resultados de 60</span>
        </div>
        <div className="flex items-center gap-1">
          {[1, 2, 3, 4, 5, 6].map((page) => (
            <button
              key={page}
              className={`h-8 w-8 rounded-md text-sm font-medium transition-smooth ${
                page === 1
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-secondary"
              }`}
            >
              {page}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RecentItemsSection;
