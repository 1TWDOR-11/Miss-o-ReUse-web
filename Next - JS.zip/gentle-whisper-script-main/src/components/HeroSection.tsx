import heroImage from "@/assets/hero-reuse.jpg";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const HeroSection = () => {
  return (
    <section className="container py-12">
      <div className="grid gap-8 md:grid-cols-2 items-center">
        <div className="overflow-hidden rounded-2xl">
          <img
            src={heroImage}
            alt="Coleção de itens vintage para reutilização"
            className="w-full h-[320px] object-cover transition-smooth hover:scale-105"
          />
        </div>
        <div className="flex flex-col gap-4">
          <h1 className="text-3xl md:text-4xl font-bold leading-tight">
            Dê um <span className="underline decoration-2 underline-offset-4">novo destino</span> ao que você não usa mais.
          </h1>
          <p className="text-sm text-muted-foreground font-medium">
            Objetos com história procuram um novo começo.
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Na ReUse!, conectamos pessoas para que itens parados ganhem uma nova vida. Participe de uma comunidade que fortalece o consumo consciente, reduz o desperdício e cria novas histórias a cada troca.
          </p>
          <Link to="/produtos">
            <Button className="w-fit rounded-full px-6">
              Explore mais
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
