import productCamera from "@/assets/product-camera.jpg";
import productAnalog from "@/assets/product-analog-camera.jpg";

const NovidadesSection = () => {
  return (
    <section className="bg-secondary py-12">
      <div className="container">
        <h2 className="text-2xl font-bold mb-1">Novidades</h2>
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-1 md:row-span-2">
            <div className="overflow-hidden rounded-xl h-full">
              <img
                src={productCamera}
                alt="Sony A7RII"
                className="w-full h-full object-cover min-h-[280px] transition-smooth hover:scale-105"
              />
            </div>
            <p className="mt-2 font-semibold text-sm">Sony A7RII</p>
            <p className="text-xs text-muted-foreground">Câmera mirrorless em ótimo estado</p>
          </div>
          <div className="overflow-hidden rounded-xl">
            <img
              src={productAnalog}
              alt="Câmera analógica vintage"
              className="w-full h-[180px] object-cover transition-smooth hover:scale-105"
            />
          </div>
          <div className="overflow-hidden rounded-xl">
            <img
              src={productCamera}
              alt="Câmera digital"
              className="w-full h-[180px] object-cover transition-smooth hover:scale-105"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default NovidadesSection;
