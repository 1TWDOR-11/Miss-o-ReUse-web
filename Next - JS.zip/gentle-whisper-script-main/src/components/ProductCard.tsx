interface ProductCardProps {
  image: string;
  name: string;
  price: string;
}

const ProductCard = ({ image, name, price }: ProductCardProps) => {
  return (
    <div className="group cursor-pointer">
      <div className="overflow-hidden rounded-xl bg-secondary aspect-square">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover transition-smooth group-hover:scale-105"
        />
      </div>
      <p className="mt-2 font-semibold text-sm">{name}</p>
      <p className="text-xs text-muted-foreground">{price}</p>
    </div>
  );
};

export default ProductCard;
