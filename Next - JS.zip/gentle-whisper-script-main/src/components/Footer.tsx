import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="border-t border-border bg-card py-10">
      <div className="container">
        <div className="flex flex-col md:flex-row justify-between gap-8">
          {/* Logo & Social */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="h-8 w-8 rounded-lg bg-primary" />
              <span className="text-xl font-bold tracking-tight">
                Re<span className="font-extrabold">Use</span>!
              </span>
            </div>
            <div className="flex gap-2">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-6 w-6 rounded bg-primary" />
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <p className="font-semibold text-sm mb-3">ReUse!</p>
            <nav className="flex flex-col gap-2">
              <Link to="/" className="text-sm text-muted-foreground hover:text-foreground transition-smooth">Início</Link>
              <Link to="/produtos" className="text-sm text-muted-foreground hover:text-foreground transition-smooth">Produtos</Link>
              <Link to="/negociacao" className="text-sm text-muted-foreground hover:text-foreground transition-smooth">Negociação</Link>
              <Link to="/pedidos" className="text-sm text-muted-foreground hover:text-foreground transition-smooth">Meus pedidos</Link>
            </nav>
          </div>
        </div>

        <div className="mt-8 flex gap-6 text-xs text-muted-foreground">
          <span>• Política de Privacidade</span>
          <span>• Termos de Serviço</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
