import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import NovidadesSection from "@/components/NovidadesSection";
import RecentItemsSection from "@/components/RecentItemsSection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <HeroSection />
        <NovidadesSection />
        <RecentItemsSection />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
