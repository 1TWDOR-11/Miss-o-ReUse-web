import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Package } from "lucide-react";

const orders = [
  { id: "#001", product: "Sony A7RII", date: "12/03/2026", status: "Entregue", value: "R$3.500,00" },
  { id: "#002", product: "Luminária Vintage", date: "10/03/2026", status: "Em trânsito", value: "R$90,00" },
  { id: "#003", product: "Mochila para Notebook", date: "08/03/2026", status: "Processando", value: "R$180,00" },
];

const Pedidos = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container py-10">
        <h1 className="text-3xl font-bold mb-2">Meus pedidos</h1>
        <p className="text-sm text-muted-foreground mb-8">Acompanhe seus pedidos e entregas.</p>
        <div className="overflow-hidden rounded-xl border border-border">
          <table className="w-full text-sm">
            <thead className="bg-secondary">
              <tr>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground">Pedido</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground">Produto</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground">Data</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground">Valor</th>
                <th className="px-4 py-3 text-left font-medium text-muted-foreground">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border bg-card">
              {orders.map((order) => (
                <tr key={order.id} className="transition-smooth hover:bg-secondary/50">
                  <td className="px-4 py-3 font-medium">{order.id}</td>
                  <td className="px-4 py-3 flex items-center gap-2">
                    <Package className="h-4 w-4 text-muted-foreground" />
                    {order.product}
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{order.date}</td>
                  <td className="px-4 py-3 font-medium tabular-nums">{order.value}</td>
                  <td className="px-4 py-3">
                    <span className="rounded-full bg-secondary px-3 py-1 text-xs font-medium">
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Pedidos;
