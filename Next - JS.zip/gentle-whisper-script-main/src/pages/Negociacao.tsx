import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { MessageSquare } from "lucide-react";

const negotiations = [
  { id: 1, product: "Violão Acústico Giannini", buyer: "Maria Silva", status: "Em andamento", lastMessage: "Aceito R$250, pode ser?" },
  { id: 2, product: "Kit de Livros de Aventura", buyer: "João Santos", status: "Concluída", lastMessage: "Combinado! Vou retirar amanhã." },
  { id: 3, product: "Tênis Nike Airforce", buyer: "Ana Costa", status: "Aguardando", lastMessage: "Ainda está disponível?" },
];

const statusColors: Record<string, string> = {
  "Em andamento": "bg-accent text-accent-foreground",
  "Concluída": "bg-success text-success-foreground",
  "Aguardando": "bg-secondary text-secondary-foreground",
};

const Negociacao = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container py-10">
        <h1 className="text-3xl font-bold mb-2">Negociação</h1>
        <p className="text-sm text-muted-foreground mb-8">Acompanhe suas negociações em andamento.</p>
        <div className="space-y-4">
          {negotiations.map((n) => (
            <div key={n.id} className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 transition-smooth hover:shadow-md">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-secondary">
                <MessageSquare className="h-5 w-5 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm">{n.product}</p>
                <p className="text-xs text-muted-foreground truncate">
                  {n.buyer} — "{n.lastMessage}"
                </p>
              </div>
              <span className={`shrink-0 rounded-full px-3 py-1 text-xs font-medium ${statusColors[n.status]}`}>
                {n.status}
              </span>
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Negociacao;
