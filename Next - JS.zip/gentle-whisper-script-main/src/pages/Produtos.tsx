import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import productViolao from "@/assets/product-violao.jpg";
import productBooks from "@/assets/product-books.jpg";
import productBackpack from "@/assets/product-backpack.jpg";
import productAnalogCamera from "@/assets/product-analog-camera.jpg";
import productSneakers from "@/assets/product-sneakers.jpg";
import productLamp from "@/assets/product-lamp.jpg";
import productCamera from "@/assets/product-camera.jpg";

const allProducts = [
  { image: productViolao, name: "Violão Acústico Giannini", price: "R$300,00" },
  { image: productBooks, name: "Kit de Livros de Aventura", price: "R$120,00" },
  { image: productBackpack, name: "Mochila para Notebook", price: "R$180,00" },
  { image: productAnalogCamera, name: "Câmera analógica", price: "R$450,00" },
  { image: productSneakers, name: "Tênis Nike Airforce", price: "R$250,00" },
  { image: productLamp, name: "Luminária Vintage", price: "R$90,00" },
  { image: productCamera, name: "Sony A7RII", price: "R$3.500,00" },
];

const Produtos = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container py-10">
        <h1 className="text-3xl font-bold mb-2">Produtos</h1>
        <p className="text-sm text-muted-foreground mb-8">Encontre itens que merecem uma nova vida.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {allProducts.map((product, i) => (
            <ProductCard key={i} {...product} />
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Produtos;
