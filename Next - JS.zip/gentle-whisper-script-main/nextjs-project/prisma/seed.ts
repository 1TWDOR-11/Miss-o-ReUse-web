import prisma from "../lib/prisma";

async function main() {
  // Seed de usuários
  const usuario1 = await prisma.usuario.upsert({
    where: { email: "maria@example.com" },
    update: {},
    create: { nome: "Maria Silva", email: "maria@example.com", senha: "123456" },
  });

  const usuario2 = await prisma.usuario.upsert({
    where: { email: "joao@example.com" },
    update: {},
    create: { nome: "João Santos", email: "joao@example.com", senha: "123456" },
  });

  // Seed de produtos
  const produto1 = await prisma.produto.create({
    data: {
      nome: "Violão Acústico Giannini",
      descricao: "Violão em ótimo estado, pouco uso.",
      preco: 300.0,
      categoria: "Instrumentos",
      usuarioId: usuario1.id,
    },
  });

  const produto2 = await prisma.produto.create({
    data: {
      nome: "Kit de Livros de Aventura",
      descricao: "8 livros de aventura em bom estado.",
      preco: 120.0,
      categoria: "Livros",
      usuarioId: usuario1.id,
    },
  });

  const produto3 = await prisma.produto.create({
    data: {
      nome: "Mochila para Notebook",
      descricao: "Mochila resistente, cabe notebook de 15 polegadas.",
      preco: 180.0,
      categoria: "Acessórios",
      usuarioId: usuario2.id,
    },
  });

  const produto4 = await prisma.produto.create({
    data: {
      nome: "Câmera analógica",
      descricao: "Câmera analógica vintage, funcionando perfeitamente.",
      preco: 450.0,
      categoria: "Eletrônicos",
      usuarioId: usuario2.id,
    },
  });

  const produto5 = await prisma.produto.create({
    data: {
      nome: "Tênis Nike Airforce",
      descricao: "Tênis branco, tamanho 42, pouco uso.",
      preco: 250.0,
      categoria: "Calçados",
      usuarioId: usuario1.id,
    },
  });

  const produto6 = await prisma.produto.create({
    data: {
      nome: "Luminária Vintage",
      descricao: "Luminária de mesa estilo industrial.",
      preco: 90.0,
      categoria: "Decoração",
      usuarioId: usuario2.id,
    },
  });

  // Seed de negociações
  await prisma.negociacao.create({
    data: {
      mensagem: "Aceito R$250, pode ser?",
      status: "Em andamento",
      usuarioId: usuario2.id,
      produtoId: produto1.id,
    },
  });

  await prisma.negociacao.create({
    data: {
      mensagem: "Combinado! Vou retirar amanhã.",
      status: "Concluída",
      usuarioId: usuario1.id,
      produtoId: produto2.id,
    },
  });

  // Seed de pedidos
  await prisma.pedido.create({
    data: {
      valor: 450.0,
      status: "Entregue",
      usuarioId: usuario1.id,
      produtoId: produto4.id,
    },
  });

  await prisma.pedido.create({
    data: {
      valor: 90.0,
      status: "Em trânsito",
      usuarioId: usuario2.id,
      produtoId: produto6.id,
    },
  });

  console.log("✅ Seed concluído com sucesso!");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
