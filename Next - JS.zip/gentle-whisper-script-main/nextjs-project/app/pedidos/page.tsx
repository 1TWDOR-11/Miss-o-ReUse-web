import prisma from "@/lib/prisma";

export default async function PedidosPage() {
  // Busca pedidos do banco via Prisma
  const pedidos = await prisma.pedido.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      usuario: true,
      produto: true,
    },
  });

  return (
    <div style={{ maxWidth: 1200, margin: "0 auto", padding: "3rem 2rem" }}>
      <h1 style={{ fontSize: 30, fontWeight: 700 }}>Meus pedidos</h1>
      <p style={{ fontSize: 14, color: "#999", marginBottom: 32 }}>
        Acompanhe seus pedidos e entregas.
      </p>

      {pedidos.length === 0 ? (
        <p style={{ color: "#999" }}>Nenhum pedido realizado. Use POST /api/pedidos para criar.</p>
      ) : (
        <div style={{ borderRadius: 12, border: "1px solid #e5e5e5", overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: "#f0f0f0" }}>
                <th style={{ padding: "12px 16px", textAlign: "left", fontWeight: 500, color: "#666" }}>Pedido</th>
                <th style={{ padding: "12px 16px", textAlign: "left", fontWeight: 500, color: "#666" }}>Produto</th>
                <th style={{ padding: "12px 16px", textAlign: "left", fontWeight: 500, color: "#666" }}>Data</th>
                <th style={{ padding: "12px 16px", textAlign: "left", fontWeight: 500, color: "#666" }}>Valor</th>
                <th style={{ padding: "12px 16px", textAlign: "left", fontWeight: 500, color: "#666" }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {pedidos.map((pedido) => (
                <tr key={pedido.id} style={{ borderTop: "1px solid #e5e5e5" }}>
                  <td style={{ padding: "12px 16px", fontWeight: 500 }}>#{String(pedido.id).padStart(3, "0")}</td>
                  <td style={{ padding: "12px 16px" }}>{pedido.produto.nome}</td>
                  <td style={{ padding: "12px 16px", color: "#999" }}>
                    {pedido.createdAt.toLocaleDateString("pt-BR")}
                  </td>
                  <td style={{ padding: "12px 16px", fontWeight: 500, fontVariantNumeric: "tabular-nums" }}>
                    R${pedido.valor.toFixed(2)}
                  </td>
                  <td style={{ padding: "12px 16px" }}>
                    <span style={{
                      background: "#f0f0f0", padding: "4px 12px",
                      borderRadius: 999, fontSize: 12, fontWeight: 500,
                    }}>
                      {pedido.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
