import Link from "next/link";
import prisma from "@/lib/prisma";

export default async function HomePage() {
  // Busca produtos do banco via Prisma
  const produtosRecentes = await prisma.produto.findMany({
    take: 6,
    orderBy: { createdAt: "desc" },
    include: { usuario: true },
  });

  const totalProdutos = await prisma.produto.count();

  return (
    <div>
      {/* Hero Section */}
      <section style={{ maxWidth: 1200, margin: "0 auto", padding: "3rem 2rem" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32, alignItems: "center" }}>
          <div style={{ background: "#e5e5e5", borderRadius: 16, height: 320, display: "flex", alignItems: "center", justifyContent: "center", color: "#999" }}>
            Imagem Hero
          </div>
          <div>
            <h1 style={{ fontSize: 36, fontWeight: 700, lineHeight: 1.2, letterSpacing: "-0.02em" }}>
              Dê um <span style={{ textDecoration: "underline", textUnderlineOffset: 4 }}>novo destino</span> ao que você não usa mais.
            </h1>
            <p style={{ marginTop: 12, fontSize: 14, color: "#666" }}>
              Objetos com história procuram um novo começo.
            </p>
            <p style={{ marginTop: 8, fontSize: 14, color: "#666", lineHeight: 1.6 }}>
              Na ReUse!, conectamos pessoas para que itens parados ganhem uma nova vida.
              Participe de uma comunidade que fortalece o consumo consciente, reduz o desperdício
              e cria novas histórias a cada troca.
            </p>
            <Link href="/produtos" style={{
              display: "inline-block", marginTop: 16, padding: "10px 24px",
              background: "#1a1a1a", color: "#fff", borderRadius: 999,
              fontSize: 14, fontWeight: 500, textDecoration: "none",
            }}>
              Explore mais
            </Link>
          </div>
        </div>
      </section>

      {/* Itens Recentes — dados do Prisma */}
      <section style={{ maxWidth: 1200, margin: "0 auto", padding: "3rem 2rem" }}>
        <h2 style={{ fontSize: 24, fontWeight: 700 }}>Itens adicionados recentemente</h2>
        <p style={{ fontSize: 12, color: "#999", marginBottom: 24 }}>{totalProdutos} itens disponíveis</p>

        {produtosRecentes.length === 0 ? (
          <p style={{ color: "#999", fontSize: 14 }}>Nenhum produto cadastrado ainda. Use a API para adicionar produtos.</p>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 24 }}>
            {produtosRecentes.map((produto) => (
              <div key={produto.id} style={{ cursor: "pointer" }}>
                <div style={{
                  background: "#f0f0f0", borderRadius: 12, aspectRatio: "1",
                  display: "flex", alignItems: "center", justifyContent: "center", color: "#aaa",
                }}>
                  {produto.imagem ? (
                    <img src={produto.imagem} alt={produto.nome} style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: 12 }} />
                  ) : (
                    produto.nome.charAt(0)
                  )}
                </div>
                <p style={{ marginTop: 8, fontWeight: 600, fontSize: 14 }}>{produto.nome}</p>
                <p style={{ fontSize: 12, color: "#999" }}>R${produto.preco.toFixed(2)}</p>
                <p style={{ fontSize: 11, color: "#bbb" }}>por {produto.usuario.nome}</p>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
