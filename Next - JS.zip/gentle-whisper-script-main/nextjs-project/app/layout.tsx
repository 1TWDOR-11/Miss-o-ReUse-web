import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "ReUse! — Dê um novo destino ao que você não usa mais",
  description: "Plataforma de reutilização de itens usados. Conectamos pessoas para dar nova vida a objetos parados.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body style={{ fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif" }}>
        <header style={{
          borderBottom: "1px solid #e5e5e5",
          padding: "0 2rem",
          height: 64,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          position: "sticky",
          top: 0,
          background: "rgba(255,255,255,0.9)",
          backdropFilter: "blur(8px)",
          zIndex: 50,
        }}>
          <Link href="/" style={{ fontWeight: 800, fontSize: 20, textDecoration: "none", color: "#1a1a1a" }}>
            Re<strong>Use</strong>!
          </Link>
          <nav style={{ display: "flex", gap: 24 }}>
            <Link href="/" style={{ fontSize: 14, color: "#666", textDecoration: "none" }}>Início</Link>
            <Link href="/produtos" style={{ fontSize: 14, color: "#666", textDecoration: "none" }}>Produtos</Link>
            <Link href="/negociacao" style={{ fontSize: 14, color: "#666", textDecoration: "none" }}>Negociação</Link>
            <Link href="/pedidos" style={{ fontSize: 14, color: "#666", textDecoration: "none" }}>Meus pedidos</Link>
          </nav>
        </header>
        <main>{children}</main>
        <footer style={{ borderTop: "1px solid #e5e5e5", padding: "2rem", color: "#666", fontSize: 14 }}>
          <div style={{ display: "flex", justifyContent: "space-between", maxWidth: 1200, margin: "0 auto" }}>
            <div>
              <p style={{ fontWeight: 800, fontSize: 20, color: "#1a1a1a" }}>Re<strong>Use</strong>!</p>
            </div>
            <div style={{ display: "flex", gap: 16 }}>
              <Link href="/" style={{ color: "#666", textDecoration: "none" }}>Início</Link>
              <Link href="/produtos" style={{ color: "#666", textDecoration: "none" }}>Produtos</Link>
              <Link href="/negociacao" style={{ color: "#666", textDecoration: "none" }}>Negociação</Link>
              <Link href="/pedidos" style={{ color: "#666", textDecoration: "none" }}>Meus pedidos</Link>
            </div>
          </div>
          <p style={{ marginTop: 16, fontSize: 12 }}>• Política de Privacidade • Termos de Serviço</p>
        </footer>
      </body>
    </html>
  );
}
