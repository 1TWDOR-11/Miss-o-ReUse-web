import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// GET /api/negociacoes — Lista todas as negociações
export async function GET() {
  const negociacoes = await prisma.negociacao.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      usuario: { select: { id: true, nome: true } },
      produto: { select: { id: true, nome: true } },
    },
  });
  return NextResponse.json(negociacoes);
}

// POST /api/negociacoes — Cria uma nova negociação
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { mensagem, usuarioId, produtoId } = body;

    if (!mensagem || !usuarioId || !produtoId) {
      return NextResponse.json(
        { error: "Campos 'mensagem', 'usuarioId' e 'produtoId' são obrigatórios." },
        { status: 400 }
      );
    }

    const negociacao = await prisma.negociacao.create({
      data: { mensagem, usuarioId: parseInt(usuarioId), produtoId: parseInt(produtoId) },
    });

    return NextResponse.json(negociacao, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: "Erro ao criar negociação." }, { status: 500 });
  }
}
