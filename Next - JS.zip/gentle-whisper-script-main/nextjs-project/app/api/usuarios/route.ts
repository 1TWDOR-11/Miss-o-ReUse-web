import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// GET /api/usuarios — Lista todos os usuários
export async function GET() {
  const usuarios = await prisma.usuario.findMany({
    select: { id: true, nome: true, email: true, createdAt: true },
  });
  return NextResponse.json(usuarios);
}

// POST /api/usuarios — Cria um novo usuário
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { nome, email, senha } = body;

    if (!nome || !email || !senha) {
      return NextResponse.json(
        { error: "Campos 'nome', 'email' e 'senha' são obrigatórios." },
        { status: 400 }
      );
    }

    const usuario = await prisma.usuario.create({
      data: { nome, email, senha },
    });

    return NextResponse.json(
      { id: usuario.id, nome: usuario.nome, email: usuario.email },
      { status: 201 }
    );
  } catch (error: any) {
    if (error.code === "P2002") {
      return NextResponse.json(
        { error: "Unique constraint failed on the fields: (email)" },
        { status: 409 }
      );
    }
    return NextResponse.json({ error: "Erro interno." }, { status: 500 });
  }
}
