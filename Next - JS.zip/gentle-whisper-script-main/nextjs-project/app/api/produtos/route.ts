import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// GET /api/produtos — Lista todos os produtos
export async function GET() {
  const produtos = await prisma.produto.findMany({
    orderBy: { createdAt: "desc" },
    include: { usuario: { select: { id: true, nome: true } } },
  });
  return NextResponse.json(produtos);
}

// POST /api/produtos — Cria um novo produto
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { nome, descricao, preco, imagem, categoria, usuarioId } = body;

    if (!nome || !descricao || preco === undefined || !categoria || !usuarioId) {
      return NextResponse.json(
        { error: "Campos 'nome', 'descricao', 'preco', 'categoria' e 'usuarioId' são obrigatórios." },
        { status: 400 }
      );
    }

    const produto = await prisma.produto.create({
      data: { nome, descricao, preco: parseFloat(preco), imagem, categoria, usuarioId: parseInt(usuarioId) },
    });

    return NextResponse.json(produto, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: "Erro ao criar produto." }, { status: 500 });
  }
}
