import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// GET /api/pedidos — Lista todos os pedidos
export async function GET() {
  const pedidos = await prisma.pedido.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      usuario: { select: { id: true, nome: true } },
      produto: { select: { id: true, nome: true } },
    },
  });
  return NextResponse.json(pedidos);
}

// POST /api/pedidos — Cria um novo pedido
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { valor, usuarioId, produtoId } = body;

    if (valor === undefined || !usuarioId || !produtoId) {
      return NextResponse.json(
        { error: "Campos 'valor', 'usuarioId' e 'produtoId' são obrigatórios." },
        { status: 400 }
      );
    }

    const pedido = await prisma.pedido.create({
      data: {
        valor: parseFloat(valor),
        usuarioId: parseInt(usuarioId),
        produtoId: parseInt(produtoId),
      },
    });

    return NextResponse.json(pedido, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: "Erro ao criar pedido." }, { status: 500 });
  }
}
