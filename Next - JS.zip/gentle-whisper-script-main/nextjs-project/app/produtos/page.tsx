import prisma from "@/lib/prisma";

export default async function ProdutosPage() {
  // Busca todos os produtos do banco via Prisma
  const produtos = await prisma.produto.findMany({
    orderBy: { createdAt: "desc" },
    include: { usuario: true },
  });

  return (
    <div style={{ maxWidth: 1200, margin: "0 auto", padding: "3rem 2rem" }}>
      <h1 style={{ fontSize: 30, fontWeight: 700 }}>Produtos</h1>
      <p style={{ fontSize: 14, color: "#999", marginBottom: 32 }}>
        Encontre itens que merecem uma nova vida.
      </p>

      {produtos.length === 0 ? (
        <p style={{ color: "#999" }}>Nenhum produto cadastrado. Use POST /api/produtos para adicionar.</p>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 24 }}>
          {produtos.map((produto) => (
            <div key={produto.id}>
              <div style={{
                background: "#f0f0f0", borderRadius: 12, aspectRatio: "1",
                display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                {produto.imagem ? (
                  <img src={produto.imagem} alt={produto.nome} style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: 12 }} />
                ) : (
                  <span style={{ color: "#bbb" }}>{produto.categoria}</span>
                )}
              </div>
              <p style={{ marginTop: 8, fontWeight: 600, fontSize: 14 }}>{produto.nome}</p>
              <p style={{ fontSize: 12, color: "#999" }}>R${produto.preco.toFixed(2)}</p>
              <p style={{ fontSize: 11, color: "#bbb" }}>
                {produto.disponivel ? "Disponível" : "Indisponível"} • {produto.usuario.nome}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
