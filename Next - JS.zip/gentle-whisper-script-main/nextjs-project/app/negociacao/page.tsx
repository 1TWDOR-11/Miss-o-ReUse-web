import prisma from "@/lib/prisma";

export default async function NegociacaoPage() {
  // Busca negociações do banco via Prisma
  const negociacoes = await prisma.negociacao.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      usuario: true,
      produto: true,
    },
  });

  const statusColors: Record<string, string> = {
    "Aguardando": "#f0f0f0",
    "Em andamento": "#e8f4e8",
    "Concluída": "#d4edda",
  };

  return (
    <div style={{ maxWidth: 1200, margin: "0 auto", padding: "3rem 2rem" }}>
      <h1 style={{ fontSize: 30, fontWeight: 700 }}>Negociação</h1>
      <p style={{ fontSize: 14, color: "#999", marginBottom: 32 }}>
        Acompanhe suas negociações em andamento.
      </p>

      {negociacoes.length === 0 ? (
        <p style={{ color: "#999" }}>Nenhuma negociação em andamento. Use POST /api/negociacoes para criar.</p>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {negociacoes.map((n) => (
            <div key={n.id} style={{
              display: "flex", alignItems: "center", gap: 16,
              border: "1px solid #e5e5e5", borderRadius: 12, padding: 16,
            }}>
              <div style={{ flex: 1 }}>
                <p style={{ fontWeight: 600, fontSize: 14 }}>{n.produto.nome}</p>
                <p style={{ fontSize: 12, color: "#999" }}>
                  {n.usuario.nome} — &quot;{n.mensagem}&quot;
                </p>
              </div>
              <span style={{
                background: statusColors[n.status] || "#f0f0f0",
                padding: "4px 12px", borderRadius: 999, fontSize: 12, fontWeight: 500,
              }}>
                {n.status}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
